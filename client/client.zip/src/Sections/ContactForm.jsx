import React from 'react'
import EnquiryForm from '@/components/signup-form-demo'
const ContactForm = () => {
    return (
        <div className='grid grid-cols-2'>
            <div></div>
            <div>
                <EnquiryForm/>
            </div>
        </div>
    )
}

export default ContactForm