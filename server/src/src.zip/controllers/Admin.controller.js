const {Admin} = require("../models/auth.model.js");
const {ApiError} = require("../utils/ApiError.utils.js");
const {ApiResponse} = require("../utils/ApiResponse.utils.js");
const {asyncHandler} = require("../utils/asyncHandler.utils.js");

const registerAdmin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  console.log(email, password);

  if ([email, password].some((field) => field?.trim() === "")) {
    throw new ApiError(400, "All fields are required");
  }

  const isAlreadyExist = await Admin.findOne({ email });

  if (isAlreadyExist) {
    throw new ApiError(409, "Admin Already Exists");
  }

  const user = await Admin.create({
    email,
    password,
  });

  if (!user) {
    throw new ApiError(500, "Admin not created");
  }

  const createdUser = await Admin.findById(user._id).select("-password ");

  if (!createdUser) {
    throw new ApiError(500, "User not created");
  }

  return res
    .status(201)
    .json(new ApiResponse(201, "Admin Created", createdUser));
});

const loginAdmin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    throw new ApiError(400, "All fields are required");
  }

  const existedAdmin = await Admin.findOne({ email });
  if (!existedAdmin) {
    throw new ApiError(404, "Admin not found");
  }

  const isPasswordCorrect = await existedAdmin.isPasswordCorrect(password);

  if (!isPasswordCorrect) {
    throw new ApiError(400, "Invalid credentials");
  }

  const loggedInAdmin = await Admin.findById(existedAdmin._id).select(
    "-password "
  );

  return res
    .status(200)
    .json(
      new ApiResponse(
        200,
        { loggedInAdmin, token: "vsjdvffrfsfndlmn" },
        "Admin Logged In"
      )
    );
});

module.exports = { registerAdmin, loginAdmin };
